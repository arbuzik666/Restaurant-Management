1. Перед первым запуском убедиться, что установлены все нужные библиотеки:
Flask==3.0.2
Flask-SQLAlchemy==3.1.1
Flask-Login==0.6.3
Werkzeug==3.0.1
Jinja2==3.1.3
python-dateutil==2.9.0
SQLAlchemy==2.0.29

2. В случае их отсутствия использовать команду в терминале
cd project (Если находишься не в проекте)
pip install -r requirements.txt

3. Запуск приложения:
cd project (Если находишься не в проекте)
python app.py
