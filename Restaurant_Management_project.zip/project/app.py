import re
from flask import Flask, abort, flash, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from datetime import date, datetime, time
from collections import defaultdict
from jinja2 import Environment
from flask import session
import secrets
import os
import csv
from flask import send_from_directory
from sqlalchemy import extract
from sqlalchemy.orm import joinedload
from werkzeug.security import generate_password_hash, check_password_hash
from dateutil.relativedelta import relativedelta


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SECRET_KEY'] = 'super-secret-key-123'
db = SQLAlchemy(app)

@app.before_request
def generate_csrf_token():
    if 'csrf_token' not in session:
        session['csrf_token'] = secrets.token_hex(16)

app.jinja_env.globals.update(zip=zip)

# Настройка аутентификации
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Модели базы данных
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(100), unique=True)
    password = db.Column(db.String(200))  
    role = db.Column(db.String(20), default='user') 
    bookings = db.relationship('Booking', backref='user', lazy=True)
    role = db.Column(db.String(20), default='user')
    

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.String(10))  
    time = db.Column(db.String(5))
    guests = db.Column(db.Integer)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    created_at = db.Column(db.DateTime, default=datetime.now)
    visited = db.Column(db.Boolean, default=False) 
    total_sum = db.Column(db.Integer) 
    start_time = db.Column(db.String(5))  
    end_time = db.Column(db.String(5))
    name = db.Column(db.String(50), nullable=False)  
    phone = db.Column(db.String(20), nullable=False)  
    
class Dish(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    price = db.Column(db.Integer, nullable=False)  
    category = db.Column(db.String(50))  
    is_available = db.Column(db.Boolean, default=True)
    
class Order(db.Model):
    booking_id = db.Column(db.Integer, db.ForeignKey('booking.id'), nullable=False)
    booking = db.relationship('Booking', backref='orders')
    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.Integer, db.ForeignKey('booking.id'))
    status = db.Column(db.String(20), default='принят')  
    total = db.Column(db.Integer)  
    created_at = db.Column(db.DateTime, default=datetime.now)
    items = db.relationship('OrderItem', backref='order')

class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'))
    dish_id = db.Column(db.Integer, db.ForeignKey('dish.id', ondelete='SET NULL'))
    quantity = db.Column(db.Integer)
    dish = db.relationship('Dish', backref='order_items')

def validate_csrf_token():
    token = request.form.get('csrf_token')
    if not token or token != session.get('csrf_token'):
        return "Доступ запрещен", 403
    
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Маршруты
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/book', methods=['GET', 'POST'])
@login_required
def book():
    if request.method == 'POST':
        try:
            date_str = request.form['date']
            start_time_str = request.form['start_time']
            end_time_str = request.form['end_time']
            guests = int(request.form['guests'])
            name = request.form['name']
            phone = request.form['phone']
            

            start_time = datetime.strptime(start_time_str, '%H:%M').time()
            end_time = datetime.strptime(end_time_str, '%H:%M').time()
            
            duration = datetime.combine(date.today(), end_time) - datetime.combine(date.today(), start_time)
            if duration.total_seconds() > 3 * 3600:
                flash("❌ Максимальная продолжительность - 3 часа!", 'danger')
                return redirect(url_for('book'))

            existing = Booking.query.filter(
                (Booking.date == date_str) &
                (Booking.start_time < end_time_str) &
                (Booking.end_time > start_time_str)
            ).first()
            
            if existing:
                flash("⏳ Это время пересекается с существующей бронью!", 'danger')
                return redirect(url_for('book'))

            # Создание брони
            new_booking = Booking(
                date=date_str,
                start_time=start_time_str,
                end_time=end_time_str,
                guests=guests,
                name=name,
                phone=phone,
                user_id=current_user.id
                
            )
            
            db.session.add(new_booking)
            db.session.commit()
            
            flash("✅ Бронирование успешно создано!", 'success')
            return redirect(url_for('my_bookings'))

        except Exception as e:
            db.session.rollback()
            flash(f"⚠️ Ошибка: {str(e)}", 'danger')
            return redirect(url_for('book'))

    # GET-запрос
    bookings = Booking.query.filter(Booking.date >= datetime.utcnow().date()).all()
    serialized_bookings = [
        {"date": b.date, "start_time": b.start_time, "end_time": b.end_time}
        for b in bookings
    ]
    return render_template('book.html', bookings=serialized_bookings, datetime=datetime)

@app.route('/delete-booking/<int:booking_id>', methods=['POST'])
@login_required
def delete_booking(booking_id):
    if current_user.role not in ['admin', 'manager']:
        abort(403)
    
    booking = Booking.query.get_or_404(booking_id)
    
    try:
        Order.query.filter_by(booking_id=booking_id).delete()
        
        db.session.delete(booking)
        db.session.commit()
        flash('✅ Бронь успешно удалена', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'❌ Ошибка удаления: {str(e)}', 'danger')
    
    return redirect(url_for('manage_bookings'))

@app.route('/my-bookings')
@login_required
def my_bookings():
    bookings = Booking.query.filter_by(user_id=current_user.id).order_by(Booking.date.desc()).all()
    return render_template('my_bookings.html', bookings=bookings)

@app.route('/calendar')
@login_required
def booking_calendar():
    bookings = Booking.query.all()
    
    events = []
    for booking in bookings:
        events.append({
            'title': f'Столик ({booking.guests} чел.)',
            'start': f"{booking.date}T{booking.start_time}",
            'end': f"{booking.date}T{booking.end_time}",
            'color': '#8B0000' if (datetime.strptime(booking.end_time, '%H:%M') - 
                    datetime.strptime(booking.start_time, '%H:%M')).seconds//3600 > 2 
                    else '#DAA520'
        })
    
    return render_template('calendar.html', events=events)

@app.route('/analytics')
@login_required
def analytics():
    if current_user.role not in ['admin', 'manager']:
        return "Доступ запрещен", 403

    all_bookings = Booking.query.all()
    
    # Фильтруем только завершенные визиты с оплатой
    completed_bookings = [b for b in all_bookings if b.visited and b.total_sum]
    
    # Основные метрики
    total_bookings = len(all_bookings)
    total_visited_guests = sum(b.guests for b in completed_bookings)
    total_revenue = sum(b.total_sum for b in completed_bookings)
    avg_revenue_per_order = total_revenue / len(completed_bookings) if len(completed_bookings) > 0 else 0
    avg_revenue_per_guest = total_revenue / total_visited_guests if total_visited_guests > 0 else 0

    # Данные для графика
    sales_data = defaultdict(int)
    guests_data = defaultdict(int)
    for booking in completed_bookings:
        date = booking.date
        sales_data[date] += booking.total_sum
        guests_data[date] += booking.guests

    dates = sorted(sales_data.keys())
    revenues = [sales_data[date] for date in dates]
    guests = [guests_data[date] for date in dates]

    return render_template('analytics.html',
                         dates=dates,
                         revenues=revenues,
                         guests=guests,
                         total_bookings=total_bookings,
                         total_visited_guests=total_visited_guests,
                         total_revenue=total_revenue,
                         avg_revenue_per_order=avg_revenue_per_order,
                         avg_revenue_per_guest=avg_revenue_per_guest)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        # Проверка существующего пользователя
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash('❌ Пользователь с таким email уже существует!', 'danger')
            return redirect(url_for('register'))

        # Валидация пароля
        if len(password) < 6 or len(password) > 64:
            flash('🔒 Пароль должен быть от 6 до 64 символов!', 'danger')
            return redirect(url_for('register'))

        if not re.match(r'^[A-Za-z0-9@$!%*?#]+$', password):
            flash('⚠️ Допустимы только буквы, цифры и символы: @$!%*?#', 'danger')
            return redirect(url_for('register'))

        # Создание пользователя
        try:
            new_user = User(
                email=email,
                password=generate_password_hash(password),
                role='user'
            )
            db.session.add(new_user)
            db.session.commit()
            flash('✅ Регистрация прошла успешно! Теперь войдите в систему.', 'success')
            return redirect(url_for('login'))

        except Exception as e:
            db.session.rollback()
            flash(f'⛔ Ошибка регистрации: {str(e)}', 'danger')
            return redirect(url_for('register'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(email=request.form['email']).first()
        if user and check_password_hash(user.password, request.form['password']): 
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('home'))
        return "Неверные учетные данные!", 401
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect('/')

@app.route('/cancel-booking/<int:booking_id>', methods=['POST'])
@login_required
def cancel_booking(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    if booking.user_id != current_user.id:
        return "Нет прав для отмены", 403
    db.session.delete(booking)
    db.session.commit()
    return redirect(url_for('my_bookings'))

@app.route('/manage-bookings')
@login_required
def manage_bookings():
    if request.method == 'POST':
        validate_csrf_token()
    if current_user.role not in ['admin', 'manager']:
        return "Доступ запрещен", 403
    
    bookings = Booking.query.filter(Booking.date >= datetime.now().strftime('%Y-%m-%d')).all()
    return render_template('manage_bookings.html', bookings=bookings)

@app.route('/update-booking/<int:booking_id>', methods=['POST'])
@login_required
def update_booking(booking_id):
    if current_user.role not in ['admin', 'manager']:
        return "Доступ запрещен", 403
    
    booking = Booking.query.get_or_404(booking_id)
    
    booking.visited = 'visited' in request.form
    if request.form['total_sum']:
        try:
            total_sum_rub = float(request.form['total_sum'])
            booking.total_sum = int(total_sum_rub)
        except ValueError:
            flash('Некорректная сумма', 'danger')
    else:
        booking.total_sum = None
    
    db.session.commit()
    return redirect(url_for('manage_bookings'))

# Просмотр меню
@app.route('/menu')
def menu():
    dishes = Dish.query.order_by(Dish.category, Dish.price).all()
    categories = db.session.query(Dish.category).distinct().all()
    categories = [category[0] for category in categories]  # преобразуем в список строк
    return render_template('menu.html', dishes=dishes, categories=categories)

# Добавление/редактирование блюд (только для менеджеров и админов)
@app.route('/edit-dish/<int:dish_id>', methods=['GET', 'POST'])
@login_required
def edit_dish(dish_id):
    if current_user.role not in ['admin', 'manager']:
        return "Доступ запрещен", 403
    
    dish = Dish.query.get_or_404(dish_id) if dish_id != 0 else None
    
    if request.method == 'POST':
        if not dish:  # Создаем новое блюдо
            dish = Dish()
        
        dish.name = request.form['name']
        dish.description = request.form['description']
        dish.price = int(float(request.form['price']) * 100) 
        dish.category = request.form['category']
        
        if not dish.id:  
            db.session.add(dish)
        
        db.session.commit()
        return redirect('/menu')
    
    return render_template('edit_dish.html', 
                         dish=dish,
                         categories=["Холодные закуски", "Горячие блюда", "Напитки", "Десерты"])

# Удаление блюда
@app.route('/delete-dish/<int:dish_id>', methods=['POST'])
@login_required
def delete_dish(dish_id):
    if current_user.role not in ['admin', 'manager']:
        return "Доступ запрещен", 403
    
    dish = Dish.query.get_or_404(dish_id)
    db.session.delete(dish)
    db.session.commit()
    return redirect('/menu')

@app.route('/generate-report')
@login_required
def generate_report():
    if current_user.role != 'admin':
        abort(403)
    
    try:
        if not os.path.exists('reports'):
            os.makedirs('reports')
        
        filename = f'report_{datetime.now().strftime("%Y-%m-%d_%H-%M")}.csv'
        filepath = os.path.join('reports', filename)
        
        all_bookings = Booking.query.all()
        bookings = Booking.query.all()
        total_bookings = len(bookings)
        total_revenue = sum(b.total_sum for b in bookings if b.total_sum)
        completed_bookings = [b for b in all_bookings if b.visited and b.total_sum]
        total_visited_guests = sum(b.guests for b in completed_bookings)
        
        with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile, delimiter=';')
            
            writer.writerow([
                'Дата бронирования', 
                'Время', 
                'Имя посетителя',    
                'Телефон',          
                'Гости', 
                'Посетил', 
                'Сумма чека', 
                'Email клиента'
            ])
            
            for b in bookings:
                writer.writerow([
                    b.date,
                    f"{b.start_time} - {b.end_time}", 
                    b.name,         
                    b.phone,         
                    b.guests,
                    'Да' if b.visited else 'Нет',
                    f"{b.total_sum:.2f}" if b.total_sum else '0.00',
                    b.user.email
                ])
            writer.writerow([])
            writer.writerow(['Итоговые показатели:', '', '', '', '', '', ''])
            writer.writerow(['Всего бронирований', total_bookings])
            writer.writerow(['Посетило гостей', total_visited_guests])
            writer.writerow(['Общая выручка', f"{total_revenue:.2f} руб"])
        
        return send_from_directory('reports', filename, as_attachment=True)
    
    except Exception as e:
        flash(f'Ошибка генерации отчета: {str(e)}', 'danger')
        return redirect(url_for('analytics'))
    
@app.route('/delete-month', methods=['POST'])
@login_required
def delete_month():
    if current_user.role not in ['admin', 'manager']:
        abort(403)

    # Проверка CSRF-токена
    token = request.form.get('csrf_token')
    if not token or token != session.get('csrf_token'):
        abort(403)

    # Получение данных из формы
    month = request.form['month']
    year = request.form['year']

    try:
        # Удаление бронирований и связанных данных
        Booking.query.filter(
            extract('year', Booking.date) == year,
            extract('month', Booking.date) == month
        ).delete()

        # Удаление заказов
        Order.query.filter(
            extract('year', Order.created_at) == year,
            extract('month', Order.created_at) == month
        ).delete()

        db.session.commit()
        flash('✅ Данные за указанный месяц успешно удалены!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'❌ Ошибка удаления: {str(e)}', 'danger')

    return redirect(url_for('analytics'))

@app.route('/orders')
@login_required
def orders():
    if current_user.role not in ['admin', 'manager']:
        abort(403)
    
    orders = Order.query.options(
        joinedload(Order.booking).joinedload(Booking.user),
        joinedload(Order.items).joinedload(OrderItem.dish)
    ).order_by(Order.created_at.desc()).all()
    
    return render_template('orders.html', orders=orders)

@app.route('/update-order-status/<int:order_id>', methods=['POST'])
@login_required
def update_order_status(order_id):
    if current_user.role not in ['admin', 'manager']:
        abort(403)
    
    order = Order.query.get_or_404(order_id)
    new_status = request.form['status']
    order.status = new_status
    db.session.commit()
    return redirect(url_for('orders'))

@app.route('/create-order', methods=['GET', 'POST'])
@login_required
def create_order():
    if current_user.role not in ['admin', 'manager']:
        abort(403)

    if request.method == 'POST':
        try:
            # Создаем заказ
            booking_id = request.form['booking_id']
            new_order = Order(booking_id=booking_id, total=0)
            db.session.add(new_order)
            db.session.flush() 

            # Добавляем позиции заказа
            total = 0
            i = 0
            while f'dishes-{i}-dish_id' in request.form:
                dish_id = request.form[f'dishes-{i}-dish_id']
                quantity = int(request.form[f'dishes-{i}-quantity'])
                
                dish = Dish.query.get(dish_id)
                if dish:
                    total += dish.price * quantity
                    order_item = OrderItem(
                        order_id=new_order.id,
                        dish_id=dish_id,
                        quantity=quantity
                    )
                    db.session.add(order_item)
                i += 1

            new_order.total = total
            db.session.commit()
            return redirect(url_for('orders'))

        except Exception as e:
            db.session.rollback()
            flash(f'Ошибка: {str(e)}', 'danger')

    # Для GET-запроса
    bookings = Booking.query.filter(Booking.visited == False).all()
    dishes = Dish.query.all()
    return render_template('create_order.html', 
                         bookings=bookings, 
                         dishes=dishes)
    
@app.route('/delete-order/<int:order_id>', methods=['POST'])
@login_required
def delete_order(order_id):
    if current_user.role not in ['admin', 'manager']:
        abort(403)
    
    try:
        order = Order.query.get_or_404(order_id)
        
        # Удаляем связанные элементы заказа
        OrderItem.query.filter_by(order_id=order_id).delete()
        
        # Удаляем сам заказ
        db.session.delete(order)
        db.session.commit()
        flash('Заказ успешно удален', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка удаления: {str(e)}', 'danger')
    
    return redirect(url_for('orders'))

@app.route('/generate-orders-report')
@login_required
def generate_orders_report():
    if current_user.role not in ['admin', 'manager']:
        abort(403)
    
    try:
        # Создаем папку reports если ее нет
        if not os.path.exists('reports'):
            os.makedirs('reports')
        
        # Формируем имя файла
        filename = f'orders_report_{datetime.now().strftime("%Y-%m-%d_%H-%M")}.csv'
        filepath = os.path.join('reports', filename)
        
        # Получаем данные
        orders = Order.query.options(
            joinedload(Order.booking).joinedload(Booking.user),
            joinedload(Order.items).joinedload(OrderItem.dish)
        ).all()
        
        with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile, delimiter=';')
            
            writer.writerow([
                'Дата заказа', ' Клиент', ' Телефон', 
                ' Сумма', ' Статус', ' Состав заказа'
            ])
            
            for order in orders:
                client = order.booking.user.email
                items = ', '.join(
                    [f"{item.dish.name} ×{item.quantity}" 
                     for item in order.items]
                )
                
                writer.writerow([
                    order.created_at.strftime('%Y-%m-%d %H:%M'),
                    client,
                    f"{order.total/100:.2f}",
                    order.status,
                    items
                ])
        
        return send_from_directory('reports', filename, as_attachment=True)
    
    except Exception as e:
        flash(f'Ошибка генерации отчета: {str(e)}', 'danger')
        return redirect(url_for('orders'))

@app.route('/admin/users')
@login_required
def admin_users():
    if current_user.role != 'admin':
        abort(403)
    
    users = User.query.order_by(User.id).all()
    return render_template('admin_users.html', users=users)

@app.route('/admin/edit-user/<int:user_id>', methods=['POST'])
@login_required
def admin_edit_user(user_id):
    if current_user.role != 'admin':
        abort(403)

    user = User.query.get_or_404(user_id)
    new_role = request.form.get('role')
    new_email = request.form.get('email')
    
    if new_role in ['admin', 'manager', 'user']:
        user.role = new_role
    if new_email:
        user.email = new_email
    
    db.session.commit()
    return redirect(url_for('admin_users'))

@app.route('/admin/delete-user/<int:user_id>', methods=['POST'])
@login_required
def admin_delete_user(user_id):
    if current_user.role != 'admin':
        abort(403)
    
    user = User.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    return redirect(url_for('admin_users'))

@app.route('/admin/add-user', methods=['POST'])
@login_required
def admin_add_user():
    if current_user.role != 'admin':
        abort(403)
    
    email = request.form.get('email')
    password = request.form.get('password')
    role = request.form.get('role', 'user')
    
    if User.query.filter_by(email=email).first():
        flash('Пользователь с таким email уже существует!', 'danger')
        return redirect(url_for('admin_users'))
    
    new_user = User(
        email=email,
        password=generate_password_hash(password),
        role=role
    )
    
    db.session.add(new_user)
    db.session.commit()
    return redirect(url_for('admin_users'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()

        if not User.query.filter_by(email="admin@example.com").first():
            admin = User(
                email="admin@example.com",
                password=generate_password_hash("admin123"),  # Хеширование
                role="admin"
            )
            db.session.add(admin)
            
        if not User.query.filter_by(email="manager@example.com").first():
            manager = User(
                email="manager@example.com",
                password=generate_password_hash("manager123"),  # Хеширование
                role="manager"
            )
            db.session.add(manager)
            
        db.session.commit()
    
    app.run(debug=True)