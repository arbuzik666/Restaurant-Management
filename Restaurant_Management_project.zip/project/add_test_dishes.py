from app import app, db, Dish

def add_test_dishes():
    with app.app_context():
        # Убедимся, что таблица существует
        db.create_all()

        # Проверим, есть ли уже блюда
        if Dish.query.count() == 0:
            dishes = [
                Dish(
                    name="Хинкали",
                    description="Традиционные пельмени с мясом и бульоном внутри",
                    price=25000,  # 450.00 руб
                    category="Горячие блюда"
                ),
                Dish(
                    name="Хачапури",
                    description="Лепешка с сыром, часто с яйцом сверху",
                    price=30000,  # 50.00 руб/шт
                    category="Горячие блюда"
                ),
                Dish(
                    name="Пхали",
                    description="Закуска из овощей и орехов, часто с зеленью",
                    price=20000,  # 250.00 руб
                    category="Напитки"
                ),
                Dish(
                    name="Лобио",
                    description="Блюдо из фасоли с пряностями и зеленью",
                    price=22000,  # 450.00 руб
                    category="Горячие блюда"
                ),
                Dish(
                    name="Чахохбили",
                    description="Тушеная курица с томатами и специями",
                    price=35000,  # 450.00 руб
                    category="Горячие блюда"
                )               
                
                             
            ]

            db.session.bulk_save_objects(dishes)
            db.session.commit()
            print("Добавлено тестовых блюд:", len(dishes))
        else:
            print("В базе уже есть блюда, добавление отменено")

if __name__ == "__main__":
    add_test_dishes()